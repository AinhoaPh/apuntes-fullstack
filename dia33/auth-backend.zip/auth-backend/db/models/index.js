
export { Usuario } from './usuario.model.js';