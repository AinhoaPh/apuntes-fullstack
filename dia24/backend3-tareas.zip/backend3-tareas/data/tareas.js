export const tareas  =[
  {id:1, texto:"Comprar pan", isCompletada:false, isDeleted:null},
  {id:3, texto:"Hacer la compra", isCompletada:false, isDeleted:null},
  {id:4, texto:"Estudiar", isCompletada:false, isDeleted:null},

]
