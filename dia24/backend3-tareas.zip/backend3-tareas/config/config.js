export const PORT = 3000;
export const DOMAIN = 'http://localhost';