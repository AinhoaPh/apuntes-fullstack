export const PORT = 3000;

export const DOMAIN = 'http://localhost';

export const DB_USER="usuario";
export const DB_PASSWORD="contraseña";
export const CLUSTER="";
export const DATABASE="";

