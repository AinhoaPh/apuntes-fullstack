const Hero = () => {
    return (  
        <>
        <div className="hero" style={{ backgroundImage: `url(./imgs/fondo-hero.jpg)` }}>
        <img src="./imgs/logo.png" alt="logo-hero" />
        {/* <img src="./imgs/fondo-hero.jpg" alt="fondo-hero" /> */}
        </div>
        </>
        
    );
}
 
export default Hero;