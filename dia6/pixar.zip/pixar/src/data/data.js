export const moviePrincipal = [
    {
      title: "https://images.squarespace-cdn.com/content/v1/60241cb68df65b530cd84d95/1e6a13c7-e61e-4393-9d94-d6d76805037e/d%2B.png?format=750w",
      image: "https://images.squarespace-cdn.com/content/v1/60241cb68df65b530cd84d95/471447c0-56ae-46f2-ba47-eb8f93af3c00/wol_logo.png?format=2500w",
      bg: "https://images.squarespace-cdn.com/content/v1/60241cb68df65b530cd84d95/319ff132-f2a9-4159-89ef-1264b68b4e81/wl_home2.jpg?format=2500w",
    text: "ALL EPISODES NOW STREAMING"
    }
  ];


export  const movie = [
    {
      title: "https://images.squarespace-cdn.com/content/v1/60241cb68df65b530cd84d95/edac5088-045b-4b01-a155-7dc80f975541/MTP_Logo_TT_LtBg_v2.1.png?format=1500w",
      image: "https://images.squarespace-cdn.com/content/v1/60241cb68df65b530cd84d95/db41424e-0746-44b5-9630-bcb23c532326/ggcs_LaurieBlob_1.per16n.101.png?format=1500w",
    bg: "https://images.squarespace-cdn.com/content/v1/60241cb68df65b530cd84d95/9ae6d321-34af-4ef8-8b50-525eac838060/mtp_bg.jpg?format=2500w",
    text:""
  }

  ];
export  const gallery = [

    {

    }
  ];

export  const imageList = [
    {
      title: "",
      image: "https://images.squarespace-cdn.com/content/v1/60241cb68df65b530cd84d95/144b6fec-60ea-4f47-9971-b8a2ee389ab9/dp_title_flat.png?format=1000w",
    bg: "https://images.squarespace-cdn.com/content/v1/60241cb68df65b530cd84d95/5f00e8d5-2682-49e2-a98e-fbafc6095c29/bg.jpg?format=2500w",
    text:"NOW STREAMING"
    
  },
  {
    title: "",
    image: "https://images.squarespace-cdn.com/content/v1/60241cb68df65b530cd84d95/5c52424c-1feb-4755-99a0-a7236fd1b47e/hop2.jpg?format=1500w",
  bg: "",
  text:"MARCH 6, 2025"
  },
  {
    title: "",
    image: "https://images.squarespace-cdn.com/content/v1/60241cb68df65b530cd84d95/32a4a56b-3113-4b4a-ba36-2cc8ba032a2e/logo.png?format=1500w",
  bg: "https://images.squarespace-cdn.com/content/v1/60241cb68df65b530cd84d95/7a7b44e5-0525-47aa-8330-f45fe9661355/bg.jpg?format=2500w",
  text:"JUNE 6, 2026" 
  }

  ];